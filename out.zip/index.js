// Entry point for the Node.js app
require("./src/app");
